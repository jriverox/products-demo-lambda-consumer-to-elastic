const config = {
    elasticsearch: {        
        url: "https://search-producs-2b7petqt7rezlzjipyeeq5fxe4.us-east-1.es.amazonaws.com",
        index: "products"
    }
}

module.exports = config;